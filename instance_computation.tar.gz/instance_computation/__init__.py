from .. import detect_1

def detect(args):
    detect_1(args)